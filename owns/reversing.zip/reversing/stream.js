import { spawn } from 'node:child_process';
import { readdir } from 'node:fs/promises';
import { prepareStream, playStream } from '@dank074/discord-video-stream';

const STREAMS_DIR = new URL('./streams/', import.meta.url);

export async function listStreams() {
  const files = await readdir(STREAMS_DIR);
  return files.filter((f) => /\.(gif|mp4)$/i.test(f)).sort();
}

export function startStream(streamer, file, signal) {
  const source = new URL(file, STREAMS_DIR).pathname;
  const lower = file.toLowerCase();

  const ffmpeg = spawn(process.env.FFMPEG_PATH, [
    '-stream_loop', '-1',
    '-i', source,
    '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=black',
    '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p',
    '-g', '30', '-r', '30', '-an',
    '-f', 'nut', '-',
  ]);
  ffmpeg.stderr.on('data', (d) => process.env.DEBUG && process.stderr.write(d));

  const stop = () => { try { ffmpeg.kill(); } catch {} };
  if (signal) signal.addEventListener('abort', stop, { once: true });

  const promise = (async () => {
    const { command, output } = prepareStream(ffmpeg.stdout, {
      width: 1280, height: 720, frameRate: 30,
      bitrateVideo: 5000, bitrateVideoMax: 9000,
      includeAudio: false, videoCodec: 'H264',
      hardwareAcceleratedDecoding: false,
    }, new AbortController().signal);
    command.on('error', () => {});
    await playStream(output, streamer, undefined, new AbortController().signal);
  })();

  return { promise, stop };
}