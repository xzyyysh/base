import { spawn } from 'node:child_process';
import { readdir, stat } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
import { demux } from '@dank074/discord-video-stream';
const { AudioStream } = require(fileURLToPath(new URL('./node_modules/@dank074/discord-video-stream/dist/media/AudioStream.js', import.meta.url)));

const AUDIOS_DIR = new URL('./audios/', import.meta.url);

export async function listAudios() {
  const files = await readdir(AUDIOS_DIR);
  const audioFiles = files.filter((f) => /\.(mp3|ogg|opus|wav|m4a|flac)$/i.test(f)).sort();
  const sizes = await Promise.all(audioFiles.map(async (f) => {
    try {
      const s = await stat(new URL(f, AUDIOS_DIR));
      return (s.size / 1024 / 1024).toFixed(1) + 'M';
    } catch { return '?'; }
  }));
  return audioFiles.map((f, i) => ({ name: f, size: sizes[i] }));
}

export function playAudioFile(streamer, file, signal, volume = 50) {
  const source = new URL(file, AUDIOS_DIR).pathname;
  return runAudio(streamer, source, signal, volume);
}

let packetizerReady = false;

export function resetPacketizer() {
  packetizerReady = false;
}

async function runAudio(streamer, source, signal, volume) {
  if (signal && signal.aborted) throw new Error('aborted');
  const conn = streamer.voiceConnection.webRtcConn;
  if (!conn) throw new Error('No voice connection');

  if (!packetizerReady) {
    conn.setPacketizer('H264');
    packetizerReady = true;
  }
  conn.mediaConnection.setSpeaking(true);

  const vol = Math.max(0, Math.min(100, volume)) / 100;
  const ffmpeg = spawn(process.env.FFMPEG_PATH, [
    '-i', source,
    '-af', `volume=${vol}`,
    '-c:a', 'libopus', '-b:a', '128k', '-ar', '48000', '-ac', '2',
    '-f', 'nut', '-',
  ]);

  let aborted = false;
  const onAbort = () => { aborted = true; ffmpeg.kill(); };
  if (signal) signal.addEventListener('abort', onAbort, { once: true });

  ffmpeg.stderr.on('data', (d) => process.env.DEBUG && process.stderr.write(d));

  let aStream;
  let audioStream;
  try {
    const { audio } = await demux(ffmpeg.stdout, { format: 'nut' });
    if (!audio) throw new Error('No audio stream');
    aStream = new AudioStream(conn);
    audioStream = audio.stream;
    audioStream.pipe(aStream);
    await new Promise((resolve, reject) => {
      aStream.once('finish', resolve);
      aStream.once('error', reject);
      ffmpeg.on('error', () => reject(new Error('ffmpeg error')));
    });
  } finally {
    if (aStream) aStream.destroy();
    if (audioStream) audioStream.unpipe(aStream);
    conn.mediaConnection.setSpeaking(false);
    ffmpeg.kill();
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}
