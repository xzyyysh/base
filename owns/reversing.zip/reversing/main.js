import 'dotenv/config';
import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
const require = createRequire(import.meta.url);
process.env.FFMPEG_PATH ||= (() => {
  const staticBin = require('ffmpeg-static');
  return existsSync(staticBin) ? staticBin : 'ffmpeg';
})();
import prompts from 'prompts';
import chalk from 'chalk';
import { Client } from 'discord.js-selfbot-v13';
import { Streamer } from '@dank074/discord-video-stream';
import { listAudios, playAudioFile, resetPacketizer } from './audio.js';
import { listStreams, startStream } from './stream.js';

const TOKEN = process.env.DISCORD_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const CHANNEL_ID = process.env.VOICE_CHANNEL_ID;

if (!TOKEN || !GUILD_ID || !CHANNEL_ID) {
  console.error(chalk.red('Missing env vars: DISCORD_TOKEN, GUILD_ID, VOICE_CHANNEL_ID'));
  process.exit(1);
}

const streamer = new Streamer(new Client());
let connected = false;
let currentAudio = null;
let currentStream = null;
let audioAbort = null;
let audioActive = false;
let volume = 50;

const logBuffer = [];
const MAX_LOGS = 500;
function captureLog(level, args) {
  const msg = args.map((a) => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
  logBuffer.push({ time: new Date().toISOString().slice(11, 23), level, msg });
  if (logBuffer.length > MAX_LOGS) logBuffer.shift();
}
function installLogCapture() {
  const origLog = console.log;
  const origError = console.error;
  const origWarn = console.warn;
  console.log = (...a) => { captureLog('log', a); origLog(...a); };
  console.error = (...a) => { captureLog('error', a); origError(...a); };
  console.warn = (...a) => { captureLog('warn', a); origWarn(...a); };
}
installLogCapture();

const HELP = chalk.cyan(`
Commands:
  join                     join the voice channel
  leave                    leave the voice channel
  stream                   stream first file from streams/ (infinite loop)
  stream <file>            stream a specific gif/mp4 from streams/
  stream stop              stop the video stream
  list-streams             list files in streams/
  play                     play all audios from audios/ in queue
  play <file>              play a specific audio from audios/
  list                     list audios in audios/
  skip                     skip current audio
  volume [0-100]           show or set volume (default 50, applies to next audio)
  stop                     stop what is running (audio and/or stream)
  logs                     view logs (↑/↓ scroll, c clear, q back)
  help                     show this help
  exit                     quit
`);

function logInfo(msg) { console.log(chalk.blue('•'), msg); }
function logOk(msg) { console.log(chalk.green('✓'), msg); }
function logErr(msg) { console.log(chalk.red('✗'), msg); }

async function main() {
  await new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error('Login timeout: check the token / network'));
      }
    }, 30000);

    streamer.client.once('ready', async () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      logOk(`Selfbot ready: ${streamer.client.user.tag}`);
      try {
        await streamer.client.user.setPresence({ status: 'dnd', activities: [] });
        logOk('Status set to DND');
      } catch (e) {
        logErr(`Failed to set DND: ${e?.message ?? e}`);
      }
      resolve();
    });

    streamer.client.once('invalidated', () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error('Invalid token: account authentication failed (INVALIDATED)'));
    });

    streamer.client.once('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error(`Account error: ${err?.message ?? err}`));
    });
  });

  streamer.client.on('voiceStateUpdate', (oldState, newState) => {
    if (newState.channelId === CHANNEL_ID) connected = true;
    if (newState.channelId !== CHANNEL_ID && oldState.channelId === CHANNEL_ID) connected = false;
  });

  console.log(HELP);

  for (;;) {
    const { cmd } = await prompts({
      type: 'text',
      name: 'cmd',
      message: chalk.magenta('cmd'),
      initial: '',
    });
    if (cmd === undefined) break;

    const trimmed = cmd.trim();
    if (!trimmed) continue;
    const [command, ...args] = trimmed.split(/\s+/);
    const arg = args.join(' ');

    try {
      await handleCommand(command, arg);
    } catch (err) {
      logErr(`Error: ${err.message}`);
    }
  }

  await shutdown();
}

async function handleCommand(command, arg) {
  switch (command) {
    case 'join': {
      if (connected) { logInfo('Already connected'); break; }
      logInfo('Joining voice channel...');
      await streamer.joinVoice(GUILD_ID, CHANNEL_ID);
      connected = true;
      logOk('Connected');
      break;
    }

    case 'leave': {
      await stopAll();
      streamer.leaveVoice();
      resetPacketizer();
      connected = false;
      logOk('Left voice channel');
      break;
    }

    case 'stream': {
      if (!connected) { logInfo('Use "join" first'); break; }
      if (arg.toLowerCase() === 'stop') {
        await stopStream();
        logOk('Stream stopped');
        break;
      }
      let target = arg;
      if (!target) {
        const list = await listStreams();
        if (!list.length) { logInfo('(streams/ is empty)'); break; }
        target = list[0];
        logInfo(`No file specified, using first: ${target}`);
      }
      await stopStream();
      logInfo(`Streaming ${target}...`);
      const stream = startStream(streamer, target, new AbortController().signal);
      currentStream = stream;
      stream.promise
        .then(() => {
          if (currentStream === stream) { currentStream = null; logOk('Stream finished'); }
        })
        .catch((e) => {
          if (currentStream === stream) { currentStream = null; logErr(`Stream error: ${e.message}`); }
        });
      break;
    }

    case 'list-streams': {
      const list = await listStreams();
      if (!list.length) { logInfo('(streams/ is empty)'); break; }
      list.forEach((f) => console.log('  ' + chalk.yellow(f)));
      break;
    }

    case 'play': {
      if (!connected) { logInfo('Use "join" first'); break; }
      const audios = await listAudios();
      if (!audios.length) { logInfo('(audios/ is empty)'); break; }
      await stopAudio();
      if (arg) {
        const match = audios.find((a) => a.name === arg);
        if (!match) { logInfo(`"${arg}" not found`); break; }
        logInfo(`Playing ${arg}...`);
        playOne(streamer, arg).catch((e) => logErr(`Error: ${e.message}`));
      } else {
        logInfo(`Queueing ${audios.length} audios:`);
        audios.forEach((a) => console.log('  - ' + chalk.yellow(a.name)));
        playQueue(streamer, audios.map((a) => a.name));
      }
      break;
    }

    case 'list': {
      const list = await listAudios();
      if (!list.length) { logInfo('(audios/ is empty)'); break; }
      list.forEach((a) => console.log(`  ${chalk.yellow(a.name)} (${chalk.gray(a.size)})`));
      break;
    }

    case 'skip': {
      await skip();
      break;
    }

    case 'stop': {
      await stopInteractive();
      break;
    }

    case 'volume': {
      await setVolume(arg);
      break;
    }

    case 'logs': {
      await showLogs();
      break;
    }

    case 'help': {
      console.log(HELP);
      break;
    }

    case 'exit': {
      await shutdown();
      break;
    }

    default:
      logInfo(`Unknown command: ${command}. Use "help".`);
  }
}

function playOne(streamer, file) {
  audioAbort = new AbortController();
  audioActive = true;
  const p = playAudioFile(streamer, file, audioAbort.signal, volume);
  p.finally(() => { audioActive = false; }).catch(() => {});
  return p;
}

async function playQueue(streamer, files) {
  currentAudio = { files, index: 0, aborted: false };
  audioActive = true;
  await playNext();
}

async function playNext() {
  if (!currentAudio || currentAudio.aborted) return;
  if (currentAudio.index >= currentAudio.files.length) {
    logInfo('Queue finished');
    currentAudio = null;
    audioActive = false;
    return;
  }
  const file = currentAudio.files[currentAudio.index];
  logInfo(`[${currentAudio.index + 1}/${currentAudio.files.length}] ${file}...`);
  currentAudio.current = file;
  audioAbort = new AbortController();
  audioAbort.signal.addEventListener('abort', () => { if (currentAudio) currentAudio.aborted = true; });
  try {
    await playAudioFile(streamer, file, audioAbort.signal, volume);
    if (!currentAudio.aborted) {
      currentAudio.index++;
      await playNext();
    }
  } catch (e) {
    if (currentAudio && !currentAudio.aborted) logErr(`Audio error: ${e.message}`);
    currentAudio = null;
  }
}

async function skip() {
  if (audioAbort) audioAbort.abort();
  await new Promise((r) => setTimeout(r, 300));
}

async function stopAudio() {
  if (audioAbort) audioAbort.abort();
  audioAbort = null;
  currentAudio = null;
  audioActive = false;
  await new Promise((r) => setTimeout(r, 300));
}

async function stopStream() {
  if (currentStream) {
    try { currentStream.stop(); } catch {}
  }
  currentStream = null;
  await new Promise((r) => setTimeout(r, 300));
}

async function stopAll() {
  await stopAudio();
  await stopStream();
}

async function stopInteractive() {
  const streamActive = currentStream !== null;
  const options = [];
  if (audioActive) options.push({ title: 'audio', value: 'audio' });
  if (streamActive) options.push({ title: 'stream', value: 'stream' });

  if (!options.length) {
    logInfo('Nothing is running to stop');
    return;
  }
  if (options.length === 1) {
    await stopOne(options[0].value);
    return;
  }
  options.push({ title: 'both', value: 'both' });

  const { choice } = await prompts({
    type: 'select',
    name: 'choice',
    message: chalk.magenta('What to stop?'),
    choices: options,
  });
  if (choice === undefined) return;
  await stopOne(choice);
}

async function stopOne(what) {
  if (what === 'audio') {
    await stopAudio();
    logOk('Audio stopped');
  } else if (what === 'stream') {
    await stopStream();
    logOk('Stream stopped');
  } else if (what === 'both') {
    await stopAll();
    logOk('Stopped');
  }
}

async function shutdown() {
  await stopAll();
  streamer.leaveVoice();
  logOk('Bye');
  process.exit(0);
}

async function setVolume(arg) {
  if (!arg) {
    logInfo(`Volume is ${volume}%`);
    return;
  }
  const parsed = parseInt(arg, 10);
  if (isNaN(parsed)) {
    logInfo('Usage: volume <0-100>');
    return;
  }
  const clamped = Math.max(0, Math.min(100, parsed));
  volume = clamped;
  logOk(`Volume set to ${volume}%`);
  logInfo('Applies to the next audio played');
}

async function showLogs() {
  if (!logBuffer.length) {
    logInfo('No logs yet');
    return;
  }
  let offset = 0;
  const PAGE = 15;

  async function render() {
    console.log('\n' + chalk.cyan('═══ Logs ═══'));
    const start = Math.max(0, logBuffer.length - PAGE - offset);
    const slice = logBuffer.slice(start);
    if (!slice.length) { console.log('  (no more logs)'); }
    slice.forEach((l) => {
      const color = l.level === 'error' ? chalk.red : l.level === 'warn' ? chalk.yellow : chalk.gray;
      console.log(`  ${color(l.time)} ${color(l.level.padEnd(5))} ${l.msg}`);
    });
    console.log(chalk.cyan('─'.repeat(30)));
    console.log(chalk.cyan('[↑/↓] scroll') + '  ' + chalk.cyan('[c] clear') + '  ' + chalk.cyan('[q] back'));
  }

  await render();
  const keypress = (await import('node:readline')).emitKeypressEvents;
  keypress(process.stdin);
  process.stdin.setRawMode(true);
  process.stdin.resume();

  await new Promise((resolve) => {
    const onKey = (str, key) => {
      if (key.name === 'c') {
        logBuffer.length = 0;
        console.clear();
        console.log('Logs cleared');
        process.stdin.removeListener('keypress', onKey);
        resolve();
        return;
      }
      if (key.name === 'q' || key.name === 'escape' || (key.ctrl && key.name === 'c')) {
        process.stdin.removeListener('keypress', onKey);
        resolve();
        return;
      }
      if (key.name === 'up') {
        offset = Math.min(offset + 1, logBuffer.length);
        console.clear();
        render().then(() => {});
        return;
      }
      if (key.name === 'down') {
        offset = Math.max(offset - 1, 0);
        console.clear();
        render().then(() => {});
        return;
      }
    };
    process.stdin.on('keypress', onKey);
  });

  process.stdin.setRawMode(false);
  process.stdin.pause();
}

main().catch((err) => {
  logErr(`Fatal: ${err.message}`);
  console.log(chalk.red('Closing...'));
  setTimeout(() => process.exit(1), 1500);
});

streamer.client.login(TOKEN).catch((err) => {
  logErr(`Login failed: ${err?.message ?? err}`);
  console.log(chalk.red('Closing...'));
  setTimeout(() => process.exit(1), 1500);
});
